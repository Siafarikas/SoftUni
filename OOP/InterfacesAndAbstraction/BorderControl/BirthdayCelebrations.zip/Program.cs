﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<string> birthdays = new List<string>();
            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }
                string[] info = input.Split(" ");
                if (info[0] == "Robot")
                {
                    continue;
                }
                else 
                {
                    birthdays.Add(info.Last());
                }
            }

            string year = Console.ReadLine();
            birthdays = birthdays.Where(x => x.EndsWith(year)).ToList();
            foreach (var birthday in birthdays)
            {
                Console.WriteLine(birthday);
            }

        }
    }
}
