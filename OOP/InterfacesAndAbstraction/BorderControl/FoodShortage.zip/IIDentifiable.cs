﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IIDentifiable
    {
        public string Id { get; set; }
    }
}
