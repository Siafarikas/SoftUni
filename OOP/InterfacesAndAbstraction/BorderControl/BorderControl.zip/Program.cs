﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> citizens = new List<IIdentifiable>();
            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }
                string[] info = input.Split(" ");
                IIdentifiable citizen;
                if (info.Length == 3)
                {
                    citizen = new Citizen(info[2]);
                }
                else
                {
                    citizen = new Robot(info[1]);
                }
                citizens.Add(citizen);
            }
            string digits = Console.ReadLine();
            List<IIdentifiable> fakeCitizens = citizens.Where(x => x.Id.EndsWith(digits)).ToList();
            foreach (var citizen in fakeCitizens)
            {
                Console.WriteLine(citizen.Id);
            }
        }
    }
}
