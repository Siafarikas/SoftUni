﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : Vehicle
    {
        private double fuelConsumption;
        private const double DefaultAirConditionerFuelConsumption = 0.9;
        public Car(double fuelQuantity, double fuelConsumption)
            : base(fuelQuantity, fuelConsumption)
        {

        }

        public override double FuelConsumption
        {
            get
            {
                return this.fuelConsumption;
            }
            set
            {
                fuelConsumption = value + DefaultAirConditionerFuelConsumption;
            }
        }

        public override void Refuel(double fuelAmount)
        {
            this.FuelQuantity += fuelAmount;
        }

    }
}
