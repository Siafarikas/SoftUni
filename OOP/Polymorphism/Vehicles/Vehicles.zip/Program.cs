﻿using System;

namespace Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            Car car = new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]));
            string[] truckInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            Truck truck = new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]));

            int nCommands = int.Parse(Console.ReadLine());
            for (int i = 0; i < nCommands; i++)
            {
                string[] parts = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string command = parts[0];
                string vehicleType = parts[1];
                double commandValue = double.Parse(parts[2]);
                Vehicle vehicle;
                if (vehicleType == "Car")
                {
                    vehicle = car;
                }
                else
                {
                    vehicle = truck;
                }
                if (command == "Drive")
                {
                    string vehicleName;
                    if (vehicle is Car)
                    {
                        vehicleName = "Car";
                    }
                    else
                    {
                        vehicleName = "Truck";
                    }
                    if (vehicle.FuelQuantity >= commandValue * vehicle.FuelConsumption)
                    {
                        vehicle.Drive(commandValue);
                        Console.WriteLine($"{vehicleName} travelled {commandValue} km");
                    }
                    else
                    {
                        Console.WriteLine($"{vehicleName} needs refueling");
                    }
                }
                else
                {
                    vehicle.Refuel(commandValue);
                }
            }
            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}
