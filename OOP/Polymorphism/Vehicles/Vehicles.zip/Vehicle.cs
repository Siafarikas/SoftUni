﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        public double FuelQuantity { get; set; }
        public abstract double FuelConsumption { get; set; }

        protected Vehicle(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }
        public void Drive(double distance)
        {
            this.FuelQuantity -= distance * this.FuelConsumption;
        }

        public abstract void Refuel(double fuelAmount);
    }
}
