﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehiclesNew.IO
{
    public interface IReader
    {
        string CustomReadLine();
    }
}
