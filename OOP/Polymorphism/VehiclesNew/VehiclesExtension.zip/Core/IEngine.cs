﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VehiclesNew.Core
{
    public interface IEngine
    {
        void Run();

    }
}
