﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs.Output
{
    public  class ProductOutputDto
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public string Seller { get; set; }

    }
}
