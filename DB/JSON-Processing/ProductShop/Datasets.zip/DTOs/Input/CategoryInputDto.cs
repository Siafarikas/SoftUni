﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DTOs.Input
{
    public class CategoryInputDto
    {
        public string Name { get; set; }
    }
}
