﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => "Server=.;Database=BookShop;Integrated Security=False;User Id=sa;Password=yourStrong(!)Password;";
    }
}
